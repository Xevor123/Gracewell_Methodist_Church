package com.example.gracewellchurchbotnav.ui.JoinMinistry;

import android.os.Bundle;

import com.example.gracewellchurchbotnav.ui.donations.DonationsFragment;
import com.google.android.material.bottomnavigation.BottomNavigationView;
import com.google.android.material.navigation.NavigationBarView;
import com.google.android.material.snackbar.Snackbar;

import androidx.annotation.NonNull;
import androidx.appcompat.app.AppCompatActivity;

import android.view.Gravity;
import android.view.MenuItem;
import android.view.View;
import android.widget.PopupMenu;

import androidx.core.view.WindowCompat;
import androidx.navigation.NavController;
import androidx.navigation.Navigation;
import androidx.navigation.ui.AppBarConfiguration;
import androidx.navigation.ui.NavigationUI;

import com.example.gracewellchurchbotnav.databinding.ActivityJoinMinistryBinding;

import com.example.gracewellchurchbotnav.R;

public class JoinMinistryActivity extends AppCompatActivity {

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_join_ministry);

        if (findViewById(R.id.main_activity) != null) {
            if (savedInstanceState != null) {
                return;
            }

            // Create a new fragment instance
            JoinMinistryMainFragment myFragment = new JoinMinistryMainFragment();

            // Add the fragment to the container
            getSupportFragmentManager().beginTransaction()
                    .add(R.id.main_activity, myFragment).commit();
        }

        BottomNavigationView bottomNavigationView = findViewById(R.id.bottom_navigation);
        bottomNavigationView.setLabelVisibilityMode(NavigationBarView.LABEL_VISIBILITY_LABELED);
        bottomNavigationView.setOnItemSelectedListener(new NavigationBarView.OnItemSelectedListener() {
            @Override
            public boolean onNavigationItemSelected(@NonNull MenuItem item) {
                // Call the onMenuItemSelected method from the outer class and pass the selected item
                int itemID = item.getItemId();

                if (itemID == R.id.navigation_menu)
                {
                    showPopupMenu(bottomNavigationView);
                    return true;
                }
                return false;
            }
        });
    }

    private void showPopupMenu(BottomNavigationView bottomNavView) {
        PopupMenu popupMenu = new PopupMenu(this, bottomNavView, Gravity.END);
        popupMenu.getMenuInflater().inflate(R.menu.menu_popup, popupMenu.getMenu());

        // Set up a listener for the items in the popup menu
        popupMenu.setOnMenuItemClickListener(new PopupMenu.OnMenuItemClickListener() {
            @Override
            public boolean onMenuItemClick(MenuItem menuItem) {
                int itemId = menuItem.getItemId();

                if (itemId == R.id.nav_Donations)
                {
                    DonationsFragment donationsFragment = new DonationsFragment();
                    getSupportFragmentManager().beginTransaction().replace(R.id.main_activity, donationsFragment).commit();
                    return true;
                }
                if (itemId == R.id.nav_Join_Us)
                {
                    JoinMinistryMainFragment joinMinistryMainFragment = new JoinMinistryMainFragment();
                    getSupportFragmentManager().beginTransaction().replace(R.id.main_activity, joinMinistryMainFragment).commit();
                    return true;
                }
                return false;
            }
        });
        popupMenu.show();
    }

}